package com.marco.getfilepath;

import android.os.Bundle;

public interface CallbackBundle {
	abstract void callback(Bundle bundle);  

}
