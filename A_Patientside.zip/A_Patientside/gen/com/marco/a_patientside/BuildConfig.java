/** Automatically generated file. DO NOT MODIFY */
package com.marco.a_patientside;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}